tag @e[tag=ag_shockwave] remove INIT
scoreboard players add @s shockwave_distance 1
execute unless score @s shockwave_distance matches 121.. run summon item_display ~ ~ ~ {Tags:[ag_shockwave,INIT],transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1f,1000f,0.2f]},item:{id:"minecraft:glowstone_dust",count:1b,components:{"minecraft:item_model":"ancient_artifacts:misc/shockwave"}},view_range:2f,brightness:{sky:0,block:15}}
execute as @e[tag=ag_shockwave,tag=INIT] run tp @s ~ 0 ~ ~ ~
execute unless score @s shockwave_distance matches 121.. rotated ~3 0 run function ancient_artifacts:artifact_golem/attacks/summon_shockwave