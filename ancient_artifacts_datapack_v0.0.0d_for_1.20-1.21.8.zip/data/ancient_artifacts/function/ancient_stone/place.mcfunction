execute at @s unless block ~ ~ ~ air run tp @s ~ ~1 ~
execute at @s unless block ~ ~ ~ air run tp @s ~ ~-2 ~
execute at @s unless block ~ ~ ~ air run kill @s
execute at @s unless block ~ ~ ~ air run return fail

execute at @s align xyz run summon item_display ~0.5 ~0.5 ~0.5 {Tags: [ancient_stone,control], transformation: {left_rotation: [0f, 0f, 0f, 1f], right_rotation: [0f, 0f, 0f, 1f], translation: [0f, 0f, 0f], scale: [1.001f, 1.001f, 1.001f]}, interpolation_duration: 4, item: {id: "minecraft:cod_spawn_egg", count: 1b, components: {"minecraft:item_model": "ancient_artifacts:block/ancient_stone"}}}
execute at @s align xyz run summon interaction ~0.5 ~-0.005 ~0.5 {width:1.01f,height:1.01f,Tags:[ancient_stone,interact]}
execute at @s align xyz run summon item_display ~0.5 ~0.01 ~0.5 {Tags: [ancient_stone, item], item_display: "fixed", transformation: {translation: [0.0f, 1f, 0.0f], right_rotation: [0.0f, 0.0f, 0.0f, 1.0f], scale: [1.5000563f, 1.5000563f, 1.4999996f], left_rotation: [0.0f, 0.0f, 0.92387944f, -0.3826834f]}, teleport_duration: 10}

execute at @s run playsound minecraft:block.deepslate.place block @a ~ ~ ~ 1 1
#hitbox
execute at @s align xyz positioned ~0.375 ~0.01 ~0.375 run summon item_display ~ ~ ~ {Passengers: [{id: "minecraft:shulker", Silent: 1b, Invulnerable: 1b, PersistenceRequired:1b, DeathLootTable: "minecraft:empty", NoAI: 1b, AttachFace: 0b, active_effects: [{id: "minecraft:invisibility", duration: -1, show_particles: 0b}], attributes: [{id: "minecraft:scale", base: 0.75d}], Tags: [ancient_stone, hitbox,"no_damage"]}], Tags: [ancient_stone, hitbox]}
execute at @s align xyz positioned ~0.625 ~0.01 ~0.375 run summon item_display ~ ~ ~ {Passengers: [{id: "minecraft:shulker", Silent: 1b, Invulnerable: 1b, PersistenceRequired:1b, DeathLootTable: "minecraft:empty", NoAI: 1b, AttachFace: 0b, active_effects: [{id: "minecraft:invisibility", duration: -1, show_particles: 0b}], attributes: [{id: "minecraft:scale", base: 0.75d}], Tags: [ancient_stone, hitbox,"no_damage"]}], Tags: [ancient_stone, hitbox]}
execute at @s align xyz positioned ~0.375 ~0.01 ~0.625 run summon item_display ~ ~ ~ {Passengers: [{id: "minecraft:shulker", Silent: 1b, Invulnerable: 1b, PersistenceRequired:1b, DeathLootTable: "minecraft:empty", NoAI: 1b, AttachFace: 0b, active_effects: [{id: "minecraft:invisibility", duration: -1, show_particles: 0b}], attributes: [{id: "minecraft:scale", base: 0.75d}], Tags: [ancient_stone, hitbox,"no_damage"]}], Tags: [ancient_stone, hitbox]}
execute at @s align xyz positioned ~0.625 ~0.01 ~0.625 run summon item_display ~ ~ ~ {Passengers: [{id: "minecraft:shulker", Silent: 1b, Invulnerable: 1b, PersistenceRequired:1b, DeathLootTable: "minecraft:empty", NoAI: 1b, AttachFace: 0b, active_effects: [{id: "minecraft:invisibility", duration: -1, show_particles: 0b}], attributes: [{id: "minecraft:scale", base: 0.75d}], Tags: [ancient_stone, hitbox,"no_damage"]}], Tags: [ancient_stone, hitbox]}

#reset
kill @s