execute if entity @s[tag=focused] run scoreboard players add @s artifact 1

execute if score @s attack matches 1.. as @e[type=!#ancient_artifacts:non_living] store result score @s hurt run data get entity @s HurtTime
execute if score @s artifact matches 125 if score @s attack matches 1.. if predicate ancient_artifacts:random/25 at @n[scores={hurt=9..10},distance=0.01..5] run function ancient_artifacts:artifacts/end/pulse_watch/pulse {distance:3}
execute if score @s artifact matches 126 if score @s attack matches 1.. if predicate ancient_artifacts:random/25 at @n[scores={hurt=9..10},distance=0.01..10] run function ancient_artifacts:artifacts/end/pulse_watch/pulse {distance:5}
execute if score @s artifact matches 127 if score @s attack matches 1.. if predicate ancient_artifacts:random/35 at @n[scores={hurt=9..10},distance=0.01..10] run function ancient_artifacts:artifacts/end/pulse_watch/pulse {distance:5}
execute if score @s artifact matches 128 if score @s attack matches 1.. if predicate ancient_artifacts:random/35 at @n[scores={hurt=9..10},distance=0.01..15] run function ancient_artifacts:artifacts/end/pulse_watch/pulse {distance:7}
execute if score @s artifact matches 129 if score @s attack matches 1.. if predicate ancient_artifacts:random/45 at @n[scores={hurt=9..10},distance=0.01..15] run function ancient_artifacts:artifacts/end/pulse_watch/pulse {distance:7}