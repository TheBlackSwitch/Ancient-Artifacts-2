##Overworld
execute if score @s artifact matches 1..4 run return run function ancient_artifacts:artifacts/overworld/healing_amulet/active
execute if score @s artifact matches 5..7 run return run function ancient_artifacts:artifacts/overworld/poison_amulet/active
execute if score @s artifact matches 8..12 run return run function ancient_artifacts:artifacts/overworld/conductive_bracelet/active
execute if score @s artifact matches 13..14 run return run function ancient_artifacts:artifacts/overworld/shockwave_bracelet/active
execute if score @s artifact matches 15..17 run return run function ancient_artifacts:artifacts/overworld/final_shout_crown/active
execute if score @s artifact matches 18..19 run return run function ancient_artifacts:artifacts/overworld/deactivation_crown/active
execute if score @s artifact matches 20..22 run return run function ancient_artifacts:artifacts/overworld/explorers_boots/active
execute if score @s artifact matches 23..26 run return run function ancient_artifacts:artifacts/overworld/travelers_boots/active
execute if score @s artifact matches 27..29 run return run function ancient_artifacts:artifacts/overworld/miners_crown/active
execute if score @s artifact matches 30..32 run return run function ancient_artifacts:artifacts/overworld/divers_boots/active
execute if score @s artifact matches 33..37 run return run function ancient_artifacts:artifacts/overworld/allies_amulet/active
execute if score @s artifact matches 38 run return run function ancient_artifacts:artifacts/overworld/farmers_boots/active
execute if score @s artifact matches 39..43 run return run function ancient_artifacts:artifacts/overworld/reaching_bracelet/active

##Nether
execute if score @s artifact matches 44..46 run return run function ancient_artifacts:artifacts/nether/burning_ring/active
execute if score @s artifact matches 47..50 run return run function ancient_artifacts:artifacts/nether/thermal_tiara/active
execute if score @s artifact matches 51..53 run return run function ancient_artifacts:artifacts/nether/raging_ring/active
execute if score @s artifact matches 54..56 run return run function ancient_artifacts:artifacts/nether/withering_necklace/active
execute if score @s artifact matches 57..61 run return run function ancient_artifacts:artifacts/nether/fireball_ring/active
execute if score @s artifact matches 62..64 run return run function ancient_artifacts:artifacts/nether/saturating_necklace/active
execute if score @s artifact matches 65..66 run return run function ancient_artifacts:artifacts/nether/looting_tiara/active
execute if score @s artifact matches 67..68 run return run function ancient_artifacts:artifacts/nether/cooling_boots/active
execute if score @s artifact matches 69 run return run function ancient_artifacts:artifacts/nether/smelting_tiara/active
execute if score @s artifact matches 70..71 run return run function ancient_artifacts:artifacts/nether/builders_ring/active
execute if score @s artifact matches 72 run return run function ancient_artifacts:artifacts/nether/tinkering_tiara/active
execute if score @s artifact matches 73..75 run return run function ancient_artifacts:artifacts/nether/life_steal_necklace/active
execute if score @s artifact matches 76..78 run return run function ancient_artifacts:artifacts/nether/combo_boots/active

##Deep Dark
execute if score @s artifact matches 79..81 run return run function ancient_artifacts:artifacts/deep_dark/anklet_of_peace/active
execute if score @s artifact matches 82..83 run return run function ancient_artifacts:artifacts/deep_dark/borla_of_vision/active
execute if score @s artifact matches 84..87 run return run function ancient_artifacts:artifacts/deep_dark/experienced_chain/active
execute if score @s artifact matches 88..92 run return run function ancient_artifacts:artifacts/deep_dark/beefy_crystal/active
execute if score @s artifact matches 93..94 run return run function ancient_artifacts:artifacts/deep_dark/echoing_chain/active
execute if score @s artifact matches 95 run return run function ancient_artifacts:artifacts/deep_dark/sonic_crystal/active
execute if score @s artifact matches 96..99 run return run function ancient_artifacts:artifacts/deep_dark/echolocating_borla/active
execute if score @s artifact matches 100..101 run return run function ancient_artifacts:artifacts/deep_dark/detecting_borla/active
execute if score @s artifact matches 102..104 run return run function ancient_artifacts:artifacts/deep_dark/strengthening_anklet/active
execute if score @s artifact matches 105..108 run return run function ancient_artifacts:artifacts/deep_dark/recovery_anklet/active
execute if score @s artifact matches 109..110 run return run function ancient_artifacts:artifacts/deep_dark/recycling_crystal/active
execute if score @s artifact matches 111..113 run return run function ancient_artifacts:artifacts/deep_dark/shrinking_anklet/active
execute if score @s artifact matches 114..116 run return run function ancient_artifacts:artifacts/deep_dark/necromancy_anklet/active
execute if score @s artifact matches 117..118 run return run function ancient_artifacts:artifacts/deep_dark/bulky_chain/active

##End
execute if score @s artifact matches 119..121 run return run function ancient_artifacts:artifacts/end/attractive_toe_ring/active
execute if score @s artifact matches 122..124 run return run function ancient_artifacts:artifacts/end/gravitation_toe_ring/active
execute if score @s artifact matches 125..128 run return run function ancient_artifacts:artifacts/end/pulse_watch/active
execute if score @s artifact matches 129 run return run function ancient_artifacts:artifacts/end/voiding_medal/active
execute if score @s artifact matches 130..132 run return run function ancient_artifacts:artifacts/end/slowing_circlet/active
execute if score @s artifact matches 133..137 run return run function ancient_artifacts:artifacts/end/levitation_medal/active
execute if score @s artifact matches 138..139 run return run function ancient_artifacts:artifacts/end/radiant_watch/active
execute if score @s artifact matches 140..141 run return run function ancient_artifacts:artifacts/end/deflecting_circlet/active
execute if score @s artifact matches 142..144 run return run function ancient_artifacts:artifacts/end/landing_toe_ring/active
execute if score @s artifact matches 145..149 run return run function ancient_artifacts:artifacts/end/storing_circlet/active
execute if score @s artifact matches 150..151 run return run function ancient_artifacts:artifacts/end/dragons_breath_circlet/active
execute if score @s artifact matches 152..154 run return run function ancient_artifacts:artifacts/end/knockback_watch/active
execute if score @s artifact matches 155 run return run function ancient_artifacts:artifacts/end/focus_medal/active


