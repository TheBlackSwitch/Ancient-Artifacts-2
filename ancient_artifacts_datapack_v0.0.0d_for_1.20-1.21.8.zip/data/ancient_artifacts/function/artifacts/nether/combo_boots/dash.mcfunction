scoreboard players remove @s dash_power 1

execute unless block ^ ^ ^3 #ancient_artifacts:spawn_air run return run scoreboard players set @s dash_power 0
execute unless block ^ ^ ^2 #ancient_artifacts:spawn_air run return run scoreboard players set @s dash_power 0
execute unless block ^ ^ ^1 #ancient_artifacts:spawn_air run return run scoreboard players set @s dash_power 0

tp @s ^ ^ ^3

particle dust{color:[1.0,1.0,1.0],scale:4} ^ ^ ^3 0.3 0.3 0.3 0.1 10 force

function ancient_artifacts:tag_tamed
scoreboard players operation .search tbs.ID = @s tbs.ID
execute if entity @e[tag=!tamed,type=!#ancient_artifacts:no_damage,tag=!no_damage,predicate=!theblackswitch:matches_search_id,distance=..3] run playsound entity.zombie.attack_iron_door
execute as @e[tag=!tamed,type=!#ancient_artifacts:no_damage,tag=!no_damage,predicate=!theblackswitch:matches_search_id,distance=..3] run function ancient_artifacts:utilities/damage_entity_by_search {damage:3}


summon wind_charge ~ ~1 ~ {Motion:[0d,-1d,0d]}