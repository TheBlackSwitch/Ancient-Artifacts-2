scoreboard objectives add R dummy
scoreboard objectives add G dummy
scoreboard objectives add B dummy
scoreboard objectives add rPrev dummy
scoreboard objectives add gPrev dummy
scoreboard objectives add bPrev dummy

scoreboard objectives add level dummy
scoreboard objectives add levelPrev dummy
scoreboard objectives add max_level dummy

scoreboard objectives add tooltip_size dummy

scoreboard objectives add count dummy
scoreboard objectives add current_recipe dummy
scoreboard objectives add prev_recipe dummy

scoreboard objectives add lPercent dummy
scoreboard objectives add cPercent dummy
scoreboard objectives add uPercent dummy
scoreboard objectives add rPercent dummy
scoreboard objectives add qPercent dummy
scoreboard objectives add essences dummy

scoreboard objectives add waste_effect dummy
scoreboard objectives add using_shears dummy

